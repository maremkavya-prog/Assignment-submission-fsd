# Academia Flora – Final Full Stack

React + Vite frontend, Spring Boot backend, Hibernate/JPA persistence, H2 by default (MySQL configurable), Student/Faculty login, mobile navbar, assignment submission, grading, and due-date alerts.

## 1. Run backend in VS Code
Requirements: Java 17+ and Maven 3.9+.

```bash
cd backend
mvn spring-boot:run
```

Check:
`http://localhost:8080/api/health`

Expected:
`{"status":"UP"}`

The default H2 database is file-based at `backend/data/academiaflora` so no MySQL installation is required for the demo.

## 2. Run frontend
Open a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

## 3. Login
Student:
`student@college.edu` / `Student@123`

Faculty:
`faculty@college.edu` / `Faculty@123`

## 4. Alert system
The frontend compares the current time with each assignment deadline received from the Spring Boot API:
- more than 24 hours: no alert
- 24 hours or less: reminder
- 6 hours or less: urgent alert
- deadline passed: late/deadline-passed alert
- after a student submits: that assignment's pending alert disappears

The frontend refreshes backend data every 30 seconds.

## 5. Database
Spring Boot uses Hibernate/JPA. The database stores users, assignments, submissions, submitted file bytes, late status, marks and remarks.

To use MySQL instead of H2, set:
- `DB_URL=jdbc:mysql://HOST:3306/DATABASE?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC`
- `DB_USERNAME=...`
- `DB_PASSWORD=...`

## 6. Netlify + live backend
Netlify hosts the React frontend only. Spring Boot must be hosted separately (for example Render).

1. Deploy `/backend` as a Java web service.
2. Copy its HTTPS URL.
3. In Netlify → Site configuration → Environment variables, add:
   `VITE_API_URL=https://YOUR-BACKEND-URL`
4. Redeploy the frontend.

Do NOT leave `VITE_API_URL` pointing to localhost for a live Netlify site.

A `backend/render.yaml` is included as a deployment reference.
